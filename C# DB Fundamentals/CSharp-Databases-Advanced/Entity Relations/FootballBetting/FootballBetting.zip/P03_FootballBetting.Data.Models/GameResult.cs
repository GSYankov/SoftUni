﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P03_FootballBetting.Data.Models
{
    public enum GameResult
    {
        HomeTeamWins = 1,
        AwayTeamWins = 2,
        Draw = 'X'
    }
}
