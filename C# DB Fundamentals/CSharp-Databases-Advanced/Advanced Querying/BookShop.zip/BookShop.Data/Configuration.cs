﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BookShop.Data
{
    public class Configuration
    {
        public static string ConfigurationString = @"Server=.;Database=BookShop;Integrated Security = True;";
    }
}
