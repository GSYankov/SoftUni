﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BookShop.Models
{
   public enum EditionType
    {
        Normal, Promo, Gold
    }
}
