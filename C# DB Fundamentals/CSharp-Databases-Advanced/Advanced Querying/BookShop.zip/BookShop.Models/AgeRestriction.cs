﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BookShop.Models
{
    public enum AgeRestriction
    {
        Minor, Teen, Adult
    }
}
